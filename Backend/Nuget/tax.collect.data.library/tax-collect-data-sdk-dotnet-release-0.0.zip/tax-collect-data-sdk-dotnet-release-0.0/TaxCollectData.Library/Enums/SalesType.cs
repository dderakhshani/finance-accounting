﻿namespace TaxCollectData.Library.Enums
{
    public enum SalesType
    {
        NORMAL,
        CONTRACT_WORK,
        AMANI
    }
}
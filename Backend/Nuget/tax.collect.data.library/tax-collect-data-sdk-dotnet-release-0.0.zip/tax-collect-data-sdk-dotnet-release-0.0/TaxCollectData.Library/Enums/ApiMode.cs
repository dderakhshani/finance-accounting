﻿namespace TaxCollectData.Library.Enums
{
    public enum ApiMode
    {
        PRODUCTION,
        SANDBOX
    }
}
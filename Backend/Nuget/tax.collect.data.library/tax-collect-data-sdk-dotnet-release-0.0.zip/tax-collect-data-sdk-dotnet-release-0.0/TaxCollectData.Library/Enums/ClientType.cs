﻿namespace TaxCollectData.Library.Enums;

public enum ClientType
{
    TSP, SELF_TSP
}
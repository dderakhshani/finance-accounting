﻿namespace TaxCollectData.Library.Enums
{
    public enum PersonType
    {
        LEGAL,
        REAL,
        FOREIGNERS,
        FOREIGN_TRAVELERS
    }
}
﻿namespace TaxCollectData.Library.Enums
{
    public enum FiscalStatus
    {
        ACTIVE,
        INACTIVE
    }
}
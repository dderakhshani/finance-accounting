﻿namespace TaxCollectData.Library.Abstraction.Signatory;

public interface IContentSignatory : ISignatory
{
    
}